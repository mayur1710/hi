# KBES_Project-11615139_K1637_B35
A Diet Recommendation System using Machine Learning Algorithms. 
To run the project prerequirements are:
Install the following by running the command:
pip install pandas
pip install numpy
pip install tkinter
pip install sklearn
pip install jupyterlabs

if already installed then ignore

Type "jupyter notebook" on command prompt and then open the ".ipynb" extension file or run "python diet_recommender.py" on cmd.
